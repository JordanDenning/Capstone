# iOS chat tutorial: Building A Realtime Messaging App

These are the project files for the [Scaledrone iOS chat tutorial](https://www.scaledrone.com/blog/posts/ios-chat-tutorial).

To run this example make sure to replace `YOUR-CHANNEL-ID` in [`ChatService.swift`](https://github.com/ScaleDrone/ios-chat-tutorial/blob/master/ScaledroneChat/ChatService.swift).

This project works with Xcode 10 and Swift 4.2.
